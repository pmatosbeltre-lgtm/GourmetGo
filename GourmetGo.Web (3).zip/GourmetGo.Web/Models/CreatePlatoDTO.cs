﻿namespace GourmetGo.Web.Models
{
    public class CreatePlatoDTO
    {
        public string Nombre { get; set; } = string.Empty;
        public decimal Precio { get; set; }
        public int MenuId { get; set; }
        public string Descripcion { get; set; } = string.Empty; 
    }
}
