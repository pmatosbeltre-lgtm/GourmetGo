using GourmetGo.Web.Components;
using GourmetGo.Web.Services;
using Microsoft.AspNetCore.Components.Authorization;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddScoped(sp => new HttpClient
{
    BaseAddress = new Uri("http://localhost:5043/")
});

builder.Services.AddScoped<RestauranteApiService>();
builder.Services.AddScoped<UsuarioApiService>();
builder.Services.AddScoped<PlatoApiService>();
builder.Services.AddScoped<ReservaApiService>();
builder.Services.AddScoped<UsuarioApiService>();
builder.Services.AddScoped<PlatoApiService>();
builder.Services.AddScoped<MenuApiService>();
//builder.Services.AddScoped<PagoApiService>(); 
//builder.Services.AddScoped<NotificacionApiService>(); 
builder.Services.AddAuthorizationCore(); 
builder.Services.AddScoped<AuthenticationStateProvider, CustomAuthStateProvider>();
builder.Services.AddCascadingAuthenticationState(); 

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
}

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
