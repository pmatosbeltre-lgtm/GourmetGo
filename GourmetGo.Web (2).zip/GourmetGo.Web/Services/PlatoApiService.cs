﻿using System.Net.Http.Json;
using GourmetGo.Web.Models;

namespace GourmetGo.Web.Services
{
    public class PlatoApiService
    {
        private readonly HttpClient _httpClient;

        public PlatoApiService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<PlatoDTO>> ObtenerPlatosPorMenuAsync(int menuId)
        {
            try
            {
                
                var response = await _httpClient.GetFromJsonAsync<Result<List<PlatoDTO>>>($"api/Plato/menu/{menuId}");

                if (response != null && response.Success)
                {
                    return response.Data;
                }
                return new List<PlatoDTO>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al traer los platos: {ex.Message}");
                return new List<PlatoDTO>();
            }
        }
    }
}
