﻿using GourmetGo.Web.Models;
using GourmetGo.Application.DTOs.Catalogo;
using System.Net.Http.Json;

namespace GourmetGo.Web.Services
{
    public class MenuApiService
    {
        private readonly HttpClient _httpClient;
        public MenuApiService(HttpClient httpClient) => _httpClient = httpClient;

        public async Task<Result<MenuDTO>> ObtenerPorRestauranteAsync(int restauranteId)
        {
            try
            {
                // Este endpoint debe existir en tu MenuController de la API
                return await _httpClient.GetFromJsonAsync<Result<MenuDTO>>($"api/Menu/restaurante/{restauranteId}");
            }
            catch (Exception ex)
            {
                return new Result<MenuDTO> { Success = false, Message = ex.Message };
            }
        }
    }
}